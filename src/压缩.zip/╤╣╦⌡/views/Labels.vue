<template>
  <Layout>
    Labels.vue
  </Layout>
</template>

<script lang="ts">
  export default {
    name: 'Labels',
  };
</script>

