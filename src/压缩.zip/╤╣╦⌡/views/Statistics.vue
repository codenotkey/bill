<template>
  <Layout>
    Statistics.vue
  </Layout>
</template>

<script lang="ts">
  export default {
    name: 'Statistics',
  };
</script>

